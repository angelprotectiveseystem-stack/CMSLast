import re
import json
import logging
import platform
import asyncio
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes
import database as db
import keyboards as kb
from helpers import safe_edit_message_text, box, separator, now_shamsi, format_log_entry, escape_md_legacy
from config import PISHVA_ID, ROLE_TOURNAMENT_MANAGER, ROLE_SECURITY_MANAGER, BOT_USERNAME
from panel_timeout import (
    schedule_panel_timeout, reset_panel_timeout, cancel_panel_timeout,
    CLOSED_WELCOME_TIMEOUT_SECONDS,
)

logger = logging.getLogger(__name__)

ADMIN_KEYWORDS = {"تنظیم مدیر", "تنظیم مدیر امنیتی", "حذف مدیر", "حذف مدیر امنیتی"}

# کلمه‌ی گفته‌شده -> نام یکتای عملیات (برای پشتیبانی از مترادف‌ها)
SIMPLE_KEYWORDS = {
    "پنل": "restart",
    "داشبورد": "dashboard",
    "وظیفه": "tasks",
    "مسابقه": "matches",
    "بازیکن": "players",
    "مخابره": "comms",
    "امنیت": "security",
    "وضعیت": "status",
    "کلاس": "classes",
    "تیم": "teams",
    "بکاپ": "backup",
    "درخواست": "requests",
    "لاگ": "logs",
    "گزارش": "logs",
    "راهنما": "help",
    "کمک": "help",
    "قرعه": "lottery",
    "جدول": "elo",
    "رتبه": "elo",
    "قهرمانان": "champions",
    "یادآور": "reminders",
    "تنظیمات": "settings",
    "فیدبک": "feedback",
    "انتقاد": "feedback",
    "شروع": "restart",
    # ─── کلمات جدید ───
    "بستن": "close_panel",
    "خروج": "close_panel",
    "مدیر ارشد": "pishva_panel",       # فقط برای مدیر ارشد پنلش رو باز می‌کنه
    "مدیریت": "pishva_panel",         # مترادف «مدیر ارشد» — مستقیم پنل مدیر ارشد
    "دست": "ai_manage_panel",         # فقط برای مدیر ارشد — پنل مدیریت دستیار
    "رصد": "ai_manage_panel",         # مترادف «دست» — پنل مدیریت دستیار
    "اطلاعات": "reply_info",       # ریپلای روی یه پیام → جزئیات کاربر
    "درباره": "reply_info",        # مترادف اطلاعات
    "کیه": "reply_info",           # مترادف اطلاعات
    "آنلاین": "online_admins",     # لیست ادمین‌های آنلاین/فعال
    "الان": "online_admins",       # مترادف آنلاین
    "ادمین‌ها": "admin_list",      # لیست همه ادمین‌ها
    "ادمینا": "admin_list",
    "مدیران": "admin_list",
    "آمار": "quick_stats",         # آمار سریع بازیکنان و مسابقات
    "نتایج": "recent_results",     # آخرین نتایج مسابقات
    "اخطارها": "warnings_list",    # لیست بازیکنان با اخطار
    "بازی": "live_chess",          # باز کردن منوی شطرنج زنده
    "شطرنج": "live_chess",         # مترادف بازی
}

PISHVA_ONLY_ACTIONS = {
    "security", "status", "backup", "requests", "logs", "reminders", "settings",
    "pishva_panel", "online_admins", "ai_manage_panel",
}


# ─── محافظت از مالکیت پنل ────────────────────────────────────
async def panel_ownership_guard(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    """
    اگه کسی روی پنل یه نفر دیگه دست بزنه، هشدار بده و متوقف کن.
    فقط در گروه/سوپرگروه فعاله.

    FIX 1: اگه owner_id ثبت نشده (None)، در گروه دکمه‌ها رو بلاک می‌کنه
            (قبلاً با None بود pass می‌شد — یعنی هر کسی می‌تونست بزنه).
    FIX 2: اگه مدیر ارشد روی پنل «مدیریت مدیران» بزنه، اخطار امنیتی می‌گیره.
            (مدیر ارشد نباید توی گروه به پنل مدیران دست بزنه.)
    """
    from telegram.ext import ApplicationHandlerStop
    query = update.callback_query
    if not query:
        return

    chat = update.effective_chat
    if not chat or chat.type not in ("group", "supergroup"):
        return

    msg = query.message
    if not msg:
        return

    requester_id = query.from_user.id
    callback_data = query.data or ""

    # ── FIX 2: مدیر ارشد روی پنل مدیران در گروه → اخطار امنیتی ──────────
    ADMIN_MGMT_PATTERNS = (
        "menu_admins", "admin_view_", "admin_perms_",
        "admin_warn_", "admin_kick_", "perm_toggle_",
    )
    if requester_id == PISHVA_ID:
        if any(callback_data.startswith(p) for p in ADMIN_MGMT_PATTERNS):
            await query.answer(
                "🚨 هشدار امنیتی!\n"
                "مدیریت مدیران در فضای گروه مجاز نیست.\n"
                "لطفاً این عملیات را در پیوی انجام دهید.",
                show_alert=True
            )
            raise ApplicationHandlerStop()
        # مدیر ارشد روی بقیه‌ی پنل‌ها آزاده — اگه صاحب پنل باشه
        msg_key = f"panel_owner_{msg.message_id}"
        owner_id = ctx.chat_data.get(msg_key) if ctx.chat_data is not None else None
        if owner_id is not None and requester_id != owner_id:
            await query.answer(
                "⛔ این پنل متعلق به شما نیست!\n"
                "برای باز کردن پنل خودتان، کلمه «پنل» را بفرستید.",
                show_alert=True
            )
            raise ApplicationHandlerStop()
        # کلیک معتبر صاحب پنل → تایمر بی‌فعالیتی رو ریست کن
        if owner_id is not None:
            reset_panel_timeout(ctx, chat.id, msg.message_id, owner_id)
        return

    # ── FIX 1: بررسی مالکیت پنل برای همه ────────────────────────────
    msg_key = f"panel_owner_{msg.message_id}"
    owner_id = ctx.chat_data.get(msg_key) if ctx.chat_data is not None else None

    if owner_id is None:
        # در گروه هیچ owner ثبت نشده → پنل قدیمی یا ناامن → بلاک کن
        await query.answer(
            "⛔ این پنل قابل استفاده نیست.\n"
            "برای باز کردن پنل خودتان، کلمه «پنل» را بفرستید.",
            show_alert=True
        )
        raise ApplicationHandlerStop()

    if requester_id == owner_id:
        # کلیک معتبر صاحب پنل → تایمر بی‌فعالیتی رو ریست کن
        reset_panel_timeout(ctx, chat.id, msg.message_id, owner_id)
        return

    await query.answer(
        "⛔ این پنل متعلق به شما نیست!\n"
        "برای باز کردن پنل خودتان، کلمه «پنل» را بفرستید.",
        show_alert=True
    )
    raise ApplicationHandlerStop()


async def _clear_previous_panel(update: Update, ctx: ContextTypes.DEFAULT_TYPE,
                                 chat_id: int, uid: int, new_msg_id: int):
    """پنلِ قبلیِ همین کاربر (در همین گروه) رو، اگه هنوز باز مونده باشه، حذف
    می‌کنه. این باعث می‌شه با گفتنِ هر کلمه‌ی جدید («پنل»، «بستن»/«خروج» و...)
    فقط یک پنل به‌ازای هر کاربر توی گروه باز بمونه، نه چندتا هم‌زمان."""
    if ctx.chat_data is None:
        return
    key = f"active_panel_msg_{uid}"
    prev_msg_id = ctx.chat_data.get(key)
    if not prev_msg_id or prev_msg_id == new_msg_id:
        return
    cancel_panel_timeout(ctx, chat_id, prev_msg_id)
    ctx.chat_data.pop(f"panel_owner_{prev_msg_id}", None)
    try:
        await ctx.bot.delete_message(chat_id=chat_id, message_id=prev_msg_id)
    except Exception as e:
        logger.debug(f"could not delete previous panel message {prev_msg_id} in {chat_id}: {e}")


async def register_panel_owner(update: Update, ctx: ContextTypes.DEFAULT_TYPE, msg_id: int,
                                timeout_seconds: int = None):
    """صاحب پنل رو ثبت می‌کنه، پنلِ قبلیِ همون کاربر (اگه هنوز باز بود) رو
    حذف می‌کنه، و تایمر بسته‌شدن خودکار (عدم فعالیت) رو راه‌اندازی می‌کنه.
    timeout_seconds برای override کردنِ بازه‌ی پیش‌فرض (۳ دقیقه)."""
    chat = update.effective_chat
    if not chat or chat.type not in ("group", "supergroup"):
        return
    uid = update.effective_user.id if update.effective_user else None
    if uid and ctx.chat_data is not None:
        await _clear_previous_panel(update, ctx, chat.id, uid, msg_id)
        ctx.chat_data[f"panel_owner_{msg_id}"] = uid
        ctx.chat_data[f"active_panel_msg_{uid}"] = msg_id
        schedule_panel_timeout(ctx, chat.id, msg_id, uid, timeout_seconds=timeout_seconds)


# ─── پرسیدن محل باز شدن پنل (گروه vs پیوی) ──────────────────
async def ask_panel_location(update: Update, ctx: ContextTypes.DEFAULT_TYPE, action: str):
    """
    وقتی در گروه keyword زده می‌شه، اول می‌پرسه:
    «می‌خواید پنل اینجا (گروه) باز بشه یا در پیوی؟»
    action رو در user_data ذخیره می‌کنه تا بعد از انتخاب استفاده بشه.
    """
    from telegram.ext import ApplicationHandlerStop
    chat = update.effective_chat
    if not chat or chat.type not in ("group", "supergroup"):
        return False  # در پیوی نپرس، مستقیم باز کن

    uid = update.effective_user.id
    # ذخیره action برای استفاده بعد از انتخاب
    ctx.user_data["pending_panel_action"] = action

    from chess_challenge import _resolve_bot_username
    bot_username = await _resolve_bot_username(ctx.bot)

    markup = InlineKeyboardMarkup([
        [
            InlineKeyboardButton("📲 همینجا (گروه)", callback_data=f"open_panel_here_{action}"),
            InlineKeyboardButton("🔒 پیوی (امن‌تر)", url=f"https://t.me/{bot_username}?start=panel_{action}"),
        ]
    ])
    sent = await update.message.reply_text(
        f"📌 می‌خواید پنل *{_action_label(action)}* کجا باز بشه؟\n\n"
        "🔒 *پیوی* — امن‌تر، فقط شما می‌بینید\n"
        "📲 *همینجا* — در گروه، با قفل مالکیت",
        reply_markup=markup,
        parse_mode="Markdown"
    )
    # ثبت مالکیت پیام سوال، وگرنه وقتی کاربر روی «همینجا» کلیک کنه،
    # panel_ownership_guard چون owner_id ثبت‌نشده می‌بینه، پیام «پنل قابل استفاده نیست» می‌ده.
    # این کار پنلِ قبلیِ همین کاربر (اگه هنوز باز بود) رو هم حذف می‌کنه.
    await register_panel_owner(update, ctx, sent.message_id)
    raise ApplicationHandlerStop()


def _action_label(action: str) -> str:
    labels = {
        "dashboard": "داشبورد",
        "matches": "مسابقات",
        "players": "بازیکنان",
        "teams": "تیم‌ها",
        "comms": "مخابرات",
        "tasks": "وظایف",
        "classes": "کلاس‌ها",
        "lottery": "قرعه‌کشی",
        "pishva_panel": "پنل مدیر ارشد",
        "ai_manage_panel": "مدیریت دستیار",
        "security": "امنیت",
        "backup": "بکاپ",
        "requests": "درخواست‌ها",
        "logs": "لاگ‌ها",
        "settings": "تنظیمات",
        "reminders": "یادآورها",
        "help": "راهنما",
        "restart": "خوش‌آمدگویی",
    }
    return labels.get(action, action)


async def _panel_content(action: str, uid: int, is_pishva: bool, admin):
    """
    محتوای (متن، کیبورد) مربوط به یه اکشن پنل رو برمی‌گردونه.
    این تابع منبع مشترکِ محتواست: هم «همینجا (گروه)» و هم دیپ‌لینک پیوی
    از همینجا محتوا می‌گیرن تا دقیقاً یک چیز نمایش داده بشه.

    خروجی: (text, markup, err)
    - موفق: (text, markup, None)
    - ناموفق: (None, None, پیام‌خطا)
    """
    if action == "pishva_panel":
        if not is_pishva:
            return None, None, "⛔ شما مجوز باز کردن این پنل را ندارید."
        return box("👑 پنل مدیر ارشد"), kb.kb_pishva_main(), None

    if action == "ai_manage_panel":
        if not is_pishva:
            return None, None, "⛔ شما مجوز باز کردن این پنل را ندارید."
        ai_online = await db.get_setting("ai_online", "1")
        return (
            f"{box('🧑\u200d💻 مدیریت دستیار')}\n\n📌 یک گزینه را انتخاب کنید:",
            kb.kb_ai_manage_menu(ai_online, "menu_pishva"),
            None,
        )

    if action == "dashboard":
        from dashboard import build_dashboard_pishva_text, build_dashboard_admin_text
        if is_pishva:
            dtext = await build_dashboard_pishva_text()
            return dtext, kb.kb_dashboard_pishva(), None
        dtext = await build_dashboard_admin_text(uid)
        return dtext, kb.kb_dashboard_admin(), None

    if action == "matches":
        return box("♟️ مدیریت مسابقات"), kb.kb_matches_menu(), None

    if action == "players":
        role_key = "pishva" if is_pishva else admin["role"]
        return box("👤 مدیریت بازیکنان"), kb.kb_players_menu(role_key), None

    if action == "teams":
        team_mode = await db.get_setting("team_mode_enabled", "0")
        if team_mode != "1":
            return None, None, "❗ حالت تیمی در حال حاضر غیرفعال است."
        return box("🏆 مدیریت تیم‌ها"), kb.kb_teams_menu(), None

    if action == "comms":
        if is_pishva:
            return box("📡 مخابرات"), kb.kb_comms_pishva(), None
        return box("📡 مخابرات"), kb.kb_comms_admin(), None

    if action == "tasks":
        if is_pishva:
            return box("📋 وظایف"), kb.kb_tasks_pishva(), None
        return box("📋 وظایف"), kb.kb_tasks_admin(), None

    if action == "classes":
        return box("🏫 مدیریت کلاس‌ها"), kb.kb_class_manage(), None

    if action == "lottery":
        return (
            f"{box('🎲 قرعه‌کشی هوشمند')}\n\n📌 محدوده بازیکنان:",
            kb.kb_lottery_scope(),
            None,
        )

    return None, None, "❗ این پنل پشتیبانی نمی‌شود."


async def open_panel_here(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    """
    وقتی کاربر «همینجا» رو انتخاب می‌کنه، پنل رو در گروه باز می‌کنه.
    این callback handler باید در bot.py ثبت بشه.
    """
    from telegram.ext import ApplicationHandlerStop
    query = update.callback_query
    uid = query.from_user.id

    # بررسی که فقط همون کسی که پرسید می‌تونه جواب بده
    # action از callback_data می‌گیریم: open_panel_here_{action}
    parts = query.data.split("_", 3)
    action = parts[-1] if len(parts) >= 4 else ""

    is_pishva = (uid == PISHVA_ID)
    admin = await db.get_admin(uid)
    is_admin = bool(admin and admin["is_active"])

    if not (is_pishva or is_admin):
        await query.answer("⛔ شما مجوز باز کردن پنل را ندارید.", show_alert=True)
        return

    await query.answer()

    # ─── شروع/پنل پیش‌فرض: همون چیزیه که /start نشون می‌ده ───
    if action == "restart":
        from auth import show_pishva_welcome, show_admin_welcome
        if is_pishva:
            await show_pishva_welcome(update, ctx)
        else:
            await show_admin_welcome(update, ctx, admin)
        await register_panel_owner(update, ctx, query.message.message_id)
        return

    text, markup, err = await _panel_content(action, uid, is_pishva, admin)
    if text is None:
        await safe_edit_message_text(query, err or "❗ این پنل در گروه پشتیبانی نمی‌شود. لطفاً در پیوی باز کنید.")
        return

    sent = await safe_edit_message_text(query, text, reply_markup=markup, parse_mode="Markdown")

    # ثبت مالکیت پنل
    if sent:
        msg_id = sent.message_id if hasattr(sent, "message_id") else query.message.message_id
        await register_panel_owner(update, ctx, msg_id)



async def handle_keyword_command(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    from telegram.ext import ApplicationHandlerStop
    if not update.message or not update.message.text:
        return
    text = update.message.text.strip()
    action = SIMPLE_KEYWORDS.get(text)

    if action is None and text not in ADMIN_KEYWORDS:
        return  # نه keyword → بذار ConversationHandler بگیره

    uid = update.effective_user.id if update.effective_user else None
    if not uid:
        return
    is_pishva = (uid == PISHVA_ID)
    admin = await db.get_admin(uid)
    is_admin = bool(admin and admin["is_active"])

    if not (is_pishva or is_admin):
        return

    if action and action in PISHVA_ONLY_ACTIONS and not is_pishva:
        await update.message.reply_text("⛔ این دستور فقط برای مدیر ارشد است.")
        raise ApplicationHandlerStop()

    # ─── بستن پنل (کلمه‌ی «بستن» یا «خروج») ───
    # پنلِ قبلاً بازِ همین کاربر توی گروه رو حذف می‌کنه (از طریق
    # register_panel_owner → _clear_previous_panel) و یک پیامِ تازه با
    # همون خوش‌آمدگوییِ همیشگی می‌فرستد ولی به‌جای کیبوردِ کاملِ پنل،
    # فقط ۲ دکمه زیرش می‌ذاره: لاگ‌ها و ورود به پنل. این پیام (برخلافِ
    # پنل‌های معمولی که ۳ دقیقه صبر می‌کنن) با ۱ دقیقه بی‌فعالیتی
    # خودش بسته می‌شه.
    if action == "close_panel":
        from auth import time_greeting, get_weather_line
        name = (await db.get_setting("pishva_display_name", "مدیر ارشد")) if is_pishva \
            else (admin["display_name"] or admin["full_name"])
        greeting = time_greeting(name)
        weather = await get_weather_line()
        text = greeting
        if weather:
            text += "\n" + weather
        sent = await update.message.reply_text(
            text, reply_markup=kb.kb_panel_closed_menu(), parse_mode="Markdown"
        )
        await register_panel_owner(update, ctx, sent.message_id, timeout_seconds=CLOSED_WELCOME_TIMEOUT_SECONDS)
        raise ApplicationHandlerStop()

    # ─── شطرنج زنده (کلمه‌ی «بازی» یا «شطرنج») ───
    if action == "live_chess":
        from chess_challenge import chess_menu_from_message
        sent = await chess_menu_from_message(update, ctx)
        if sent is not None:
            await register_panel_owner(update, ctx, sent.message_id)
        raise ApplicationHandlerStop()

    # ─── پنل مدیر ارشد (کلمه «مدیر ارشد») ───
    if action == "pishva_panel":
        chat = update.effective_chat
        if chat and chat.type in ("group", "supergroup"):
            await ask_panel_location(update, ctx, "pishva_panel")
        else:
            sent = await update.message.reply_text(
                box("👑 پنل مدیر ارشد"), reply_markup=kb.kb_pishva_main(), parse_mode="Markdown"
            )
            await register_panel_owner(update, ctx, sent.message_id)
        raise ApplicationHandlerStop()

    # ─── مدیریت دستیار (کلمه «دست» یا «رصد») ───
    if action == "ai_manage_panel":
        chat = update.effective_chat
        if chat and chat.type in ("group", "supergroup"):
            await ask_panel_location(update, ctx, "ai_manage_panel")
        else:
            ai_online = await db.get_setting("ai_online", "1")
            ctx.user_data["ai_manage_back"] = "menu_pishva"
            sent = await update.message.reply_text(
                f"{box('🧑\u200d💻 مدیریت دستیار')}\n\n📌 یک گزینه را انتخاب کنید:",
                reply_markup=kb.kb_ai_manage_menu(ai_online, "menu_pishva"),
                parse_mode="Markdown"
            )
            await register_panel_owner(update, ctx, sent.message_id)
        raise ApplicationHandlerStop()

    # ─── داشبورد ───
    if action == "dashboard":
        chat = update.effective_chat
        if chat and chat.type in ("group", "supergroup"):
            await ask_panel_location(update, ctx, "dashboard")
        else:
            from dashboard import build_dashboard_pishva_text, build_dashboard_admin_text
            if is_pishva:
                dtext = await build_dashboard_pishva_text()
                sent = await update.message.reply_text(dtext, reply_markup=kb.kb_dashboard_pishva(), parse_mode="Markdown")
            else:
                dtext = await build_dashboard_admin_text(uid)
                sent = await update.message.reply_text(dtext, reply_markup=kb.kb_dashboard_admin(), parse_mode="Markdown")
            await register_panel_owner(update, ctx, sent.message_id)
        raise ApplicationHandlerStop()

    # ─── اطلاعات/درباره/کیه — ریپلای روی پیام ───
    if action == "reply_info":
        target_id, target_name, target_username = _extract_reply_target(update)
        if not target_id:
            await update.message.reply_text(
                "❗ برای دیدن اطلاعات، روی پیام شخص موردنظر ریپلای کنید و «اطلاعات» بنویسید."
            )
            return
        text_lines = await _build_user_info(target_id, target_name, target_username)
        await update.message.reply_text("\n".join(text_lines), parse_mode="Markdown")
        raise ApplicationHandlerStop()

    # ─── آنلاین / الان (وضعیت لحظه‌ایِ همه‌ی ادمین‌ها) ───
    if action == "online_admins":
        admins_all = await db.get_active_admins()
        from datetime import datetime
        now_dt = datetime.now()
        ONLINE_THRESHOLD_MIN = 3  # زیر این چند دقیقه یعنی همین الان روی ربات فعاله
        STRANGER_WINDOW_MIN = 60  # غریبه‌هایی که توی این بازه فعالیت داشتن رو نشون بده

        lines = [box("👥 وضعیت ادمین‌ها"), ""]
        if not admins_all:
            lines.append("❗ هیچ مدیر فعالی ثبت نشده.")
        for a in admins_all:
            name = escape_md_legacy(a["display_name"] or a["full_name"])
            role_lbl = "🏆" if a["role"] == ROLE_TOURNAMENT_MANAGER else "🛡️"
            last = a.get("last_active")
            status = "⚫️ هیچ‌وقت از ربات استفاده نکرده"
            if last:
                try:
                    last_dt = datetime.fromisoformat(str(last))
                    diff = now_dt - last_dt
                    mins = int(diff.total_seconds() // 60)
                    if mins < ONLINE_THRESHOLD_MIN:
                        status = "🟢 آنلاین"
                    elif mins < 60:
                        status = f"🟡 آفلاین — `{mins} دقیقه پیش` فعال بوده"
                    elif mins < 1440:
                        status = f"🟠 آفلاین — `{int(mins // 60)} ساعت پیش` فعال بوده"
                    else:
                        status = f"🔴 آفلاین — `{int(mins // 1440)} روز پیش` فعال بوده"
                except Exception:
                    pass
            lines.append(f"{role_lbl} *{name}*\n    {status}")

        # ─── غریبه‌هایی که اخیراً با ربات کار کردن (نه مدیر ارشد، نه ادمین ثبت‌شده) ───
        strangers = await db.get_recent_strangers(minutes=STRANGER_WINDOW_MIN)
        keyboard_rows = []
        if strangers:
            lines.append("")
            lines.append(separator("👥 غریبه‌های اخیراً فعال"))
            lines.append(f"_(فعالیت در {STRANGER_WINDOW_MIN} دقیقه‌ی گذشته — برای جزییات روی دکمه بزن)_")
            for s in strangers:
                uname = s["username"] or ""
                fname = s["full_name"] or ""
                tid = s["telegram_id"]
                label_bits = []
                if fname:
                    label_bits.append(fname[:20])
                if uname:
                    label_bits.append(f"@{uname}")
                label_bits.append(f"#{tid}")
                label = "🙍 " + " | ".join(label_bits)
                keyboard_rows.append([InlineKeyboardButton(label[:64], callback_data=f"strangerinfo_{tid}")])
        else:
            lines.append("")
            lines.append("👥 هیچ کاربر غریبه‌ای اخیراً با ربات کار نکرده.")

        text = "\n\n".join(lines)
        markup = InlineKeyboardMarkup(keyboard_rows) if keyboard_rows else None
        try:
            await update.message.reply_text(text, reply_markup=markup, parse_mode="Markdown")
        except Exception:
            await update.message.reply_text(text, reply_markup=markup)
        raise ApplicationHandlerStop()

    # ─── لیست مدیران ───
    if action == "admin_list":
        admins_all = await db.get_active_admins()
        lines = [box(f"👥 مدیران فعال — {len(admins_all)} نفر")]
        for a in admins_all:
            name = a["display_name"] or a["full_name"]
            uname = f"@{a['username']}" if a.get("username") else "—"
            role_lbl = "🏆 مدیر مسابقات" if a["role"] == ROLE_TOURNAMENT_MANAGER else "🛡️ مدیر امنیتی"
            lines.append(f"• {name} ({uname}) — {role_lbl}")
        if not admins_all:
            lines.append("❗ هیچ مدیر فعالی ثبت نشده.")
        await update.message.reply_text("\n".join(lines), parse_mode="Markdown")
        raise ApplicationHandlerStop()

    # ─── آمار سریع ───
    if action == "quick_stats":
        all_players = await db.get_all_players()
        active_players = await db.get_continuing_players()
        all_matches = await db.get_matches_by_filter("all")
        done_matches = [m for m in all_matches if m["result"]]
        warned = [p for p in all_players if p["warnings"] > 0]
        today_m = await db.get_matches_by_filter("today")
        lines = [
            box("📊 آمار سریع"),
            separator("👤 بازیکنان"),
            f"کل: `{len(all_players)}` | فعال: `{len(active_players)}` | با اخطار: `{len(warned)}`",
            separator("♟️ مسابقات"),
            f"کل: `{len(all_matches)}` | با نتیجه: `{len(done_matches)}` | امروز: `{len(today_m)}`",
            separator(),
        ]
        await update.message.reply_text("\n".join(lines), parse_mode="Markdown")
        raise ApplicationHandlerStop()

    # ─── آخرین نتایج ───
    if action == "recent_results":
        all_matches = await db.get_matches_by_filter("all")
        done = [m for m in all_matches if m["result"]][-10:]
        done.reverse()
        if not done:
            await update.message.reply_text("❗ هنوز مسابقه‌ای با نتیجه ثبت نشده.")
            return
        lines = [box("🏆 آخرین نتایج")]
        for m in done:
            if m["result"] == "white":
                res = f"🥇 {m['white_name']} برنده"
            elif m["result"] == "black":
                res = f"🥇 {m['black_name']} برنده"
            else:
                res = "🤝 تساوی"
            lines.append(f"• {m['white_name']} vs {m['black_name']} — {res}")
        await update.message.reply_text("\n".join(lines), parse_mode="Markdown")
        raise ApplicationHandlerStop()

    # ─── لیست اخطارها ───
    if action == "warnings_list":
        all_players = await db.get_all_players()
        warned = sorted([p for p in all_players if p["warnings"] > 0],
                        key=lambda p: p["warnings"], reverse=True)
        if not warned:
            await update.message.reply_text("✅ هیچ بازیکنی اخطار فعال ندارد.")
            return
        lines = [box(f"⚠️ بازیکنان با اخطار — {len(warned)} نفر")]
        for p in warned:
            bar = "🔴" * min(p["warnings"], 3) + "⚪" * max(0, 3 - p["warnings"])
            lines.append(f"• {p['full_name']} — {bar} ({p['warnings']} اخطار)")
        await update.message.reply_text("\n".join(lines), parse_mode="Markdown")
        raise ApplicationHandlerStop()

    # ─── وظیفه ───
    if action == "tasks":
        chat = update.effective_chat
        if chat and chat.type in ("group", "supergroup"):
            await ask_panel_location(update, ctx, "tasks")
        else:
            if is_pishva:
                sent = await update.message.reply_text(box("📋 وظایف"), reply_markup=kb.kb_tasks_pishva(), parse_mode="Markdown")
            else:
                sent = await update.message.reply_text(box("📋 وظایف"), reply_markup=kb.kb_tasks_admin(), parse_mode="Markdown")
            await register_panel_owner(update, ctx, sent.message_id)
        raise ApplicationHandlerStop()

    # ─── مسابقه ───
    if action == "matches":
        chat = update.effective_chat
        if chat and chat.type in ("group", "supergroup"):
            await ask_panel_location(update, ctx, "matches")
        else:
            sent = await update.message.reply_text(
                box("♟️ مدیریت مسابقات"), reply_markup=kb.kb_matches_menu(), parse_mode="Markdown"
            )
            await register_panel_owner(update, ctx, sent.message_id)
        raise ApplicationHandlerStop()

    # ─── بازیکن ───
    if action == "players":
        chat = update.effective_chat
        if chat and chat.type in ("group", "supergroup"):
            await ask_panel_location(update, ctx, "players")
        else:
            role_key = "pishva" if is_pishva else admin["role"]
            sent = await update.message.reply_text(
                box("👤 مدیریت بازیکنان"), reply_markup=kb.kb_players_menu(role_key), parse_mode="Markdown"
            )
            await register_panel_owner(update, ctx, sent.message_id)
        raise ApplicationHandlerStop()

    # ─── مخابره ───
    if action == "comms":
        chat = update.effective_chat
        if chat and chat.type in ("group", "supergroup"):
            await ask_panel_location(update, ctx, "comms")
        else:
            if is_pishva:
                sent = await update.message.reply_text(box("📡 مخابرات"), reply_markup=kb.kb_comms_pishva(), parse_mode="Markdown")
            else:
                sent = await update.message.reply_text(box("📡 مخابرات"), reply_markup=kb.kb_comms_admin(), parse_mode="Markdown")
            await register_panel_owner(update, ctx, sent.message_id)
        raise ApplicationHandlerStop()

    # ─── امنیت ───
    if action == "security":
        current = await db.get_setting("system_status", "normal")
        await update.message.reply_text(
            f"{box('🚦 وضعیت سیستم')}\n\nوضعیت فعلی را انتخاب کنید:",
            reply_markup=kb.kb_status_select(current), parse_mode="Markdown"
        )
        raise ApplicationHandlerStop()

    # ─── وضعیت (گزارش کامل سیستم) ───
    if action == "status":
        report = await _build_system_status_report()
        await update.message.reply_text(report, parse_mode="Markdown")
        raise ApplicationHandlerStop()

    # ─── کلاس ───
    if action == "classes":
        chat = update.effective_chat
        if chat and chat.type in ("group", "supergroup"):
            await ask_panel_location(update, ctx, "classes")
        else:
            sent = await update.message.reply_text(
                box("🏫 مدیریت کلاس‌ها"), reply_markup=kb.kb_class_manage(), parse_mode="Markdown"
            )
            await register_panel_owner(update, ctx, sent.message_id)
        raise ApplicationHandlerStop()

    # ─── تیم ───
    if action == "teams":
        team_mode = await db.get_setting("team_mode_enabled", "0")
        if team_mode != "1":
            await update.message.reply_text("❗ حالت تیمی در حال حاضر غیرفعال است.")
            return
        chat = update.effective_chat
        if chat and chat.type in ("group", "supergroup"):
            await ask_panel_location(update, ctx, "teams")
        else:
            sent = await update.message.reply_text(
                box("🏆 مدیریت تیم‌ها"), reply_markup=kb.kb_teams_menu(), parse_mode="Markdown"
            )
            await register_panel_owner(update, ctx, sent.message_id)
        raise ApplicationHandlerStop()

    # ─── بکاپ ───
    if action == "backup":
        await update.message.reply_text(
            f"{box('💾 سیستم پشتیبان‌گیری')}\n\n📌 بازه زمانی را انتخاب کنید:",
            reply_markup=kb.kb_backup_main(), parse_mode="Markdown"
        )
        raise ApplicationHandlerStop()

    # ─── درخواست ───
    if action == "requests":
        reqs = await db.get_pending_requests()
        if not reqs:
            await update.message.reply_text(
                f"{box('📥 درخواست‌های دسترسی')}\n\n✅ هیچ درخواست جدیدی وجود ندارد.",
                parse_mode="Markdown"
            )
            return
        for req in reqs:
            role_label = "🏆 مدیر مسابقات" if req["role"] == ROLE_TOURNAMENT_MANAGER else "🛡️ مدیر امنیتی"
            rtext = (
                f"📥 *درخواست دسترسی*\n\n"
                f"👤 نام: {req['full_name']}\n"
                f"🔗 یوزرنیم: {req['username']}\n"
                f"💼 نقش: {role_label}\n"
                f"📝 پیام: {req['message'] or '—'}\n"
                f"⏱️ زمان: `{str(req['requested_at'])[:19]}`"
            )
            await update.message.reply_text(
                rtext, reply_markup=kb.kb_access_request(req["id"]), parse_mode="Markdown"
            )
        raise ApplicationHandlerStop()

    # ─── لاگ / گزارش ───
    if action == "logs":
        logs, total = await db.get_action_logs("today", page=0, page_size=15)
        admins_map = {a["telegram_id"]: (a["display_name"] or a["full_name"]) for a in await db.get_all_admins()}
        pname = await db.get_setting("pishva_display_name", "مدیر ارشد")
        if not logs:
            await update.message.reply_text("❗ هیچ اقدامی امروز ثبت نشده.")
            return
        lines = [box(f"🔍 لاگ اقدامات — امروز ({total} مورد)"), ""]
        for log in logs:
            name = pname if log["admin_id"] == PISHVA_ID else admins_map.get(log["admin_id"], str(log["admin_id"]))
            t = str(log["logged_at"] or "")[:16]
            lines.append(format_log_entry(t, name, log["action_type"], log["description"]))
        if total > len(logs):
            lines.append("")
            lines.append("📌 برای دیدن کامل، فیلتر بازه‌ی زمانی، و جستجو، از پنل «🔍 پیگیری اقدامات» مدیر ارشد استفاده کنید.")
        try:
            await update.message.reply_text("\n\n".join(lines), parse_mode="Markdown")
        except Exception:
            await update.message.reply_text("\n\n".join(lines))
        raise ApplicationHandlerStop()

    # ─── راهنما / کمک ───
    if action == "help":
        from help_center import kb_help_main
        role = "pishva" if is_pishva else "admin"
        await update.message.reply_text(
            box("📚 مرکز راهنمای سیستم"), reply_markup=kb_help_main(role), parse_mode="Markdown"
        )
        raise ApplicationHandlerStop()

    # ─── قرعه ───
    if action == "lottery":
        chat = update.effective_chat
        if chat and chat.type in ("group", "supergroup"):
            await ask_panel_location(update, ctx, "lottery")
        else:
            sent = await update.message.reply_text(
                f"{box('🎲 قرعه‌کشی هوشمند')}\n\n📌 محدوده بازیکنان:",
                reply_markup=kb.kb_lottery_scope(), parse_mode="Markdown"
            )
            await register_panel_owner(update, ctx, sent.message_id)
        raise ApplicationHandlerStop()

    # ─── جدول / رتبه (Elo) ───
    if action == "elo":
        try:
            from elo import get_elo_leaderboard, get_elo_title
            leaders = await get_elo_leaderboard(10)
        except Exception:
            leaders = []
        if not leaders:
            await update.message.reply_text("❗ هنوز مسابقه‌ای با نتیجه ثبت نشده.")
            return
        medals = ["🥇", "🥈", "🥉"]
        lines = [box("🏆 جدول رتبه‌بندی Elo")]
        for i, p in enumerate(leaders):
            medal = medals[i] if i < 3 else f"`{i+1}.`"
            lines.append(f"{medal} {p['full_name']} — `{int(p['rating'])}` ({get_elo_title(p['rating'])})")
        await update.message.reply_text("\n".join(lines), parse_mode="Markdown")
        raise ApplicationHandlerStop()

    # ─── قهرمانان ───
    if action == "champions":
        try:
            from features import _get_best_player_since
            from datetime import datetime, timedelta
            week_ago = (datetime.now() - timedelta(days=7)).isoformat()
            month_ago = (datetime.now() - timedelta(days=30)).isoformat()
            weekly = await _get_best_player_since(week_ago)
            monthly = await _get_best_player_since(month_ago)
        except Exception:
            weekly = monthly = None
        lines = [
            box("🏆 قهرمانان"),
            "🌟 هفته: " + (f"{weekly['name']} ({weekly['wins']} برد)" if weekly else "—"),
            "👑 ماه: " + (f"{monthly['name']} ({monthly['wins']} برد)" if monthly else "—"),
        ]
        await update.message.reply_text("\n".join(lines), parse_mode="Markdown")
        raise ApplicationHandlerStop()

    # ─── یادآور ───
    if action == "reminders":
        import reminders as rem
        master = (await db.get_setting("reminder_master_enabled", "1")) == "1"
        items = []
        for rtype, conf in rem.REMINDER_TYPES.items():
            enabled = await rem._is_enabled(rtype)
            interval = await rem._get_interval_hours(rtype)
            items.append((rtype, conf["label"], enabled, interval))
        text = (
            "⏰ تنظیمات یادآورها\n\n"
            "در این بخش می‌توانید هر یادآور را جداگانه فعال یا غیرفعال کنید "
            "و بازه‌ی زمانی ارسال آن را تنظیم نمایید."
        )
        await update.message.reply_text(text, reply_markup=kb.kb_reminders_menu(master, items), parse_mode="Markdown")
        raise ApplicationHandlerStop()

    # ─── تنظیمات ───
    if action == "settings":
        keys = ["notifications_enabled", "communications_enabled", "help_enabled",
            "match_registration_enabled", "admin_login_enabled", "bot_active_for_admins",
            "team_mode_enabled", "team_registration_enabled", "managers_can_create_teams",
            "admin_dashboard_enabled"]
        settings = {k: await db.get_setting(k, "1") for k in keys}
        await update.message.reply_text(
            f"{box('⚙️ تنظیمات ربات')}\n\n📌 گزینه موردنظر را تغییر دهید:",
            reply_markup=kb.kb_pishva_settings_simple(settings), parse_mode="Markdown"
        )
        raise ApplicationHandlerStop()

    # ─── فیدبک / انتقاد ───
    if action == "feedback":
        await update.message.reply_text(
            box("💡 انتقادات و پیشنهادات"), reply_markup=kb.kb_feedback_menu(), parse_mode="Markdown"
        )
        raise ApplicationHandlerStop()

    # ─── شروع (فقط برای کاربران قبلاً ثبت‌شده — بدون فلوی ثبت‌نام) ───
    if action == "restart":
        chat = update.effective_chat
        if chat and chat.type in ("group", "supergroup"):
            await ask_panel_location(update, ctx, "restart")
        else:
            from auth import show_pishva_welcome, show_admin_welcome
            if is_pishva:
                sent = await show_pishva_welcome(update, ctx)
            else:
                sent = await show_admin_welcome(update, ctx, admin)
            if sent is not None and hasattr(sent, "message_id"):
                await register_panel_owner(update, ctx, sent.message_id)
        raise ApplicationHandlerStop()

    # ─── تنظیم/حذف مدیر (فقط مدیر ارشد، با ریپلای) ───
    if text in ADMIN_KEYWORDS:
        if not is_pishva:
            await update.message.reply_text("⛔ این دستور فقط برای مدیر ارشد است.")
            return
        target_id, target_name, target_username = _extract_reply_target(update)
        if not target_id:
            await update.message.reply_text(
                "❗ برای این دستور باید روی پیام شخص موردنظر (یا پیامی حاوی آیدی عددی او) ریپلای کنید."
            )
            return
        if target_id == PISHVA_ID:
            await update.message.reply_text("❗ نمی‌توانید مدیر ارشد را به‌عنوان مدیر تنظیم/حذف کنید.")
            return

        if text == "تنظیم مدیر":
            await _set_admin(target_id, target_username, target_name, ROLE_TOURNAMENT_MANAGER)
            await update.message.reply_text(f"✅ {target_name} به‌عنوان 🏆 مدیر مسابقات تنظیم شد.")
        elif text == "تنظیم مدیر امنیتی":
            await _set_admin(target_id, target_username, target_name, ROLE_SECURITY_MANAGER)
            await update.message.reply_text(f"✅ {target_name} به‌عنوان 🛡️ مدیر امنیتی تنظیم شد.")
        elif text in ("حذف مدیر", "حذف مدیر امنیتی"):
            existing = await db.get_admin(target_id)
            if not existing or not existing["is_active"]:
                await update.message.reply_text("❗ این فرد در حال حاضر مدیر فعال نیست.")
                return
            await db.kick_admin(target_id)
            await db.log_action(PISHVA_ID, "kick_admin_keyword", f"حذف مدیر: {target_name}", target_id)
            await update.message.reply_text(f"✅ دسترسی مدیریت {target_name} حذف شد.")
        raise ApplicationHandlerStop()


# ─── جزییات یک کاربر «غریبه» (دکمه‌ی شیشه‌ای زیر لیست آنلاین) ───
async def stranger_info_callback(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    """callback_data = strangerinfo_<telegram_id> — فقط مدیر ارشد و مدیر امنیتی می‌بینن."""
    query = update.callback_query
    uid = query.from_user.id
    is_pishva = (uid == PISHVA_ID)
    admin = None if is_pishva else await db.get_admin(uid)
    allowed = is_pishva or (admin and admin["is_active"] and admin["role"] == ROLE_SECURITY_MANAGER)
    if not allowed:
        await query.answer("⛔ فقط مدیر ارشد یا مدیر امنیتی می‌تونه جزییات غریبه‌ها رو ببینه.", show_alert=True)
        return
    await query.answer()

    tid = int(query.data.split("_")[-1])
    summary = await db.get_stranger_summary(tid)
    log_rows = await db.get_stranger_log(tid, limit=15)

    if not summary or not summary["action_count"]:
        await query.message.reply_text("❗ اطلاعاتی از این کاربر پیدا نشد.")
        return

    uname = summary["username"] or ""
    fname = summary["full_name"] or "بی‌نام"
    lines = [
        box("🙍 جزییات کاربر غریبه"),
        "",
        f"👤 نام: *{escape_md_legacy(fname)}*",
        f"🪪 یوزرنیم: {('@' + uname) if uname else '—'}",
        f"🆔 آیدی عددی: `{tid}`",
        f"📊 تعداد کل اقدامات ثبت‌شده: {summary['action_count']}",
        f"🕐 اولین فعالیت: `{str(summary['first_seen'] or '')[:16]}`",
        f"🕐 آخرین فعالیت: `{str(summary['last_active'] or '')[:16]}`",
        "",
        separator("📋 آخرین اقدامات (جدیدترین اول)"),
    ]
    for row in log_rows:
        ts = str(row["ts"] or "")[:16]
        lines.append(f"⏱️ `{ts}` — {escape_md_legacy(row['action'] or '')}")

    text = "\n".join(lines)
    try:
        await query.message.reply_text(text, parse_mode="Markdown")
    except Exception:
        await query.message.reply_text(text)
async def _build_user_info(target_id: int, target_name: str, target_username: str) -> list:
    from datetime import datetime, timedelta
    lines = [box(f"🔍 اطلاعات — {target_name}")]

    # یوزرنیم
    uname_txt = target_username if target_username else "—"
    lines.append(f"🪪 یوزرنیم: {uname_txt}")
    lines.append(f"🆔 آیدی: `{target_id}`")
    lines.append("")

    # مدیر ارشد است؟
    if target_id == PISHVA_ID:
        pname = await db.get_setting("pishva_display_name", "مدیر ارشد")
        lines.append(f"👑 *نقش: مدیر ارشد ({pname})*")
        lines.append("🔓 دسترسی: همه چیز")
        return lines

    # ادمینه؟
    admin = await db.get_admin(target_id)
    if admin and admin["is_active"]:
        role_lbl = "🏆 مدیر مسابقات" if admin["role"] == ROLE_TOURNAMENT_MANAGER else "🛡️ مدیر امنیتی"
        lines.append(f"💼 *نقش: {role_lbl}*")
        lines.append(f"✅ وضعیت: فعال")

        # آخرین فعالیت
        last = admin.get("last_active")
        if last:
            try:
                last_dt = datetime.fromisoformat(str(last))
                diff = datetime.now() - last_dt
                mins = int(diff.total_seconds() // 60)
                if mins < 2:
                    ago = "🟢 همین الان"
                elif mins < 60:
                    ago = f"🟡 {mins} دقیقه پیش"
                elif mins < 1440:
                    ago = f"🟠 {int(mins//60)} ساعت پیش"
                else:
                    ago = f"🔴 {int(mins//1440)} روز پیش"
                lines.append(f"⏱️ آخرین فعالیت: {ago}")
            except Exception:
                pass

        # تاریخ عضویت
        joined = admin.get("joined_at")
        if joined:
            lines.append(f"📅 عضویت: `{str(joined)[:10]}`")

        # دسترسی‌ها
        lines.append("")
        lines.append(separator("🔐 دسترسی‌ها"))
        try:
            perms = json.loads(admin.get("permissions") or "{}")
            perm_labels = {
                "match_management": "♟️ مسابقات",
                "view_players": "👤 مشاهده بازیکنان",
                "issue_warning": "⚠️ صدور اخطار",
                "request_ban": "🚫 درخواست اخراج",
                "direct_ban": "❌ اخراج مستقیم",
                "edit_delete_match": "✏️ ویرایش مسابقه",
                "communications": "📡 مخابرات",
                "notifications": "🔔 اعلانات",
                "news": "📰 اخبار",
                "assign_task": "📋 وظیفه",
                "report": "🚨 گزارش",
                "senior_admin": "🌟 ارشد",
                "settings_access": "⚙️ تنظیمات",
                "ai_access": "🤖 دستیار هوشمند",
            }
            active_perms = [lbl for k, lbl in perm_labels.items() if perms.get(k, True)]
            inactive_perms = [lbl for k, lbl in perm_labels.items() if not perms.get(k, True)]
            if active_perms:
                lines.append("✅ " + " | ".join(active_perms))
            if inactive_perms:
                lines.append("❌ " + " | ".join(inactive_perms))
        except Exception:
            lines.append("دسترسی‌ها: نامشخص")

        # اخطارها
        warns = admin.get("warnings", 0)
        if warns:
            lines.append(f"\n⚠️ اخطارهای مدیریتی: `{warns}`")
    else:
        # نه مدیر ارشد، نه ادمین
        lines.append("👤 نقش: کاربر عادی")
        lines.append("❌ در سیستم ثبت نشده")

        # شاید بلاک باشه
        blocked = await db.get_blocked_user(target_id)
        if blocked:
            lines.append(f"\n🚫 *این کاربر توسط APS بلاک شده است*")
            lines.append(f"📝 دلیل: {blocked.get('reason', '—')}")

    return lines
def _extract_reply_target(update: Update):
    msg = update.message
    if not msg.reply_to_message:
        return None, None, None
    replied = msg.reply_to_message
    if replied.from_user and not replied.from_user.is_bot:
        u = replied.from_user
        name = " ".join(filter(None, [u.first_name, u.last_name])) or (u.username or str(u.id))
        username = f"@{u.username}" if u.username else ""
        return u.id, name, username
    if replied.text:
        m = re.search(r"\d{5,}", replied.text)
        if m:
            tid = int(m.group())
            return tid, f"کاربر {tid}", ""
    return None, None, None


async def _set_admin(telegram_id: int, username: str, full_name: str, role: str):
    existing = await db.get_admin(telegram_id)
    if existing:
        await db.update_admin_role_active(telegram_id, role)
    else:
        await db.create_admin(telegram_id, username, full_name, role)
    await db.log_action(PISHVA_ID, "set_admin_keyword", f"{full_name} -> {role}", telegram_id)


async def _build_system_status_report() -> str:
    try:
        import resource
        mem_kb = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
        mem_mb = round(mem_kb / 1024, 1)
        mem_txt = f"`{mem_mb}` مگابایت"
    except Exception:
        mem_txt = "نامشخص"

    status_map = {"normal": "🟢 نرمال", "bad": "🟡 احتیاطی", "danger": "🔴 خطرناک", "aps": "🪽 APS"}

    async def _teams():
        try:
            return await db.get_all_teams()
        except Exception:
            return []

    # همون فیکسِ داشبورد: ۹ تا await سریالی -> یک asyncio.gather
    (
        status, wh, db_manual, repair,
        all_players, all_matches, all_admins, all_tasks, all_classes, all_teams,
    ) = await asyncio.gather(
        db.get_setting("system_status", "normal"),
        db.get_setting("working_hours_active", "0"),
        db.get_setting("db_manual_status", "1"),
        db.get_setting("repair_mode", "0"),
        db.get_all_players(),
        db.get_matches_by_filter("all"),
        db.get_all_admins(),
        db.get_all_tasks(),
        db.get_all_classes(),
        _teams(),
    )

    lines = [
        box("🗄️ وضعیت کامل سیستم"),
        "⏱️ `" + now_shamsi() + "`",
        "",
        separator("🚦 وضعیت‌ها"),
        "📡 سیستم: " + status_map.get(status, status),
        "🕐 ساعت کاری: " + ("🟢 باز" if wh == "1" else "🔴 بسته"),
        "🗄️ دیتابیس (دستی): " + ("🟢 فعال" if db_manual == "1" else "⚠️ غیرفعال"),
        "🔧 حالت تعمیر: " + ("🔧 فعال" if repair == "1" else "✅ عادی"),
        "",
        separator("💾 حافظه و اجرا"),
        "🧠 مصرف حافظه: " + mem_txt,
        "🐍 نسخه پایتون: `" + platform.python_version() + "`",
        "",
        separator("📊 آمار دیتا"),
        "🏫 کلاس‌ها: `" + str(len(all_classes)) + "`",
        "👤 بازیکنان: `" + str(len(all_players)) + "`",
        "♟️ مسابقات: `" + str(len(all_matches)) + "`",
        "👥 مدیران (کل): `" + str(len(all_admins)) + "`",
        "📋 وظایف: `" + str(len(all_tasks)) + "`",
        "🏆 تیم‌ها: `" + str(len(all_teams)) + "`",
        separator(),
    ]
    return "\n".join(lines)


# ─── ورودی گفتگوی مخابرات از طریق کلمه (برای comms_conv) ────────
async def kw_announce_start(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    from telegram.ext import ConversationHandler
    from config import ST_ANNOUNCEMENT_TEXT
    if update.effective_user.id != PISHVA_ID:
        return ConversationHandler.END
    await update.message.reply_text("📢 متن بیانیه را وارد کنید:")
    return ST_ANNOUNCEMENT_TEXT


async def kw_news_start(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    from telegram.ext import ConversationHandler
    from config import ST_NEWS_TEXT
    if update.effective_user.id != PISHVA_ID:
        return ConversationHandler.END
    await update.message.reply_text("📰 متن خبر فوری را وارد کنید:")
    return ST_NEWS_TEXT
